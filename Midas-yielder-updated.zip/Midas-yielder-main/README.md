# Midas-yielder

Midas Yielder Bot : https://t.me/MidasRWA_bot/app?startapp=ref_86c89e68-037c-4ba2-883a-bf5fdfcaa204
# Features
- Auto Check-In Streak
- Auto Claim Reff
- Auto Play Games
- Multi Account
- Accumulate All User Points
# How to
- copy paste query_id in auth.txt
- cd midas-yielder
- pip install -r requirements.txt
- python midas.py
